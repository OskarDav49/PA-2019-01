#include <cstdlib>
#include <iostream>

using namespace std; /* cin.cout,endl*/

#define ARCHIVO TXT c:/Users/Sala5/archivo.txt //Respaldo de datos
int main(int argc, char *argv[])
{
    cout<<"HOLA MUNDO C++ Curso Programaci\'on Avanzada"<<endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
